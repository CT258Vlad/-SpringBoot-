package com.example.demo01.controller;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.example.demo01.dao.Goods.GoodsMapper;
import com.example.demo01.dao.Goods.GoodsServiceImp;
import com.example.demo01.model.Goods;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
public class GoodsController {
    @Autowired
    GoodsServiceImp goodsServiceImp;

    @ResponseBody
    @RequestMapping(value = "/getData", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    @CrossOrigin
    public List<Goods> getData()
    {
        List<Goods> datas = goodsServiceImp.getInfo();
        return datas;
    }

    @ResponseBody
    @RequestMapping(value = "/queryInfo", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    @CrossOrigin
    public String queryInfo(@RequestBody String QueryJson) {
        JSONObject queryJSON = JSONObject.parseObject(QueryJson);
        String title = queryJSON.getString("title");
        System.out.println(title);
        Map<String,Object> param = new HashMap<>();
        param.put("title",title);
        List<Map<String ,Object>> results = goodsServiceImp.queryInfo(param);
        JSONObject jsonObject = new JSONObject();
        JSONArray jsonArray = new JSONArray();
        for(Map<String,Object> result:results){
            JSONObject paramJSON = new JSONObject();
            paramJSON.put("title",result.get("title"));
            paramJSON.put("dateTime",result.get("dateTime"));
            paramJSON.put("price",result.get("price"));
            paramJSON.put("type",result.get("type"));
            jsonArray.add(paramJSON);
        }
        jsonObject.put("msg",jsonArray);
        return jsonObject.toString();
    }

    @ResponseBody
    @RequestMapping(value = "/classify", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    @CrossOrigin
    public String classify(@RequestBody String classifyJSON) {
        JSONObject ClassifyJSON = JSONObject.parseObject(classifyJSON);
        String type = ClassifyJSON.getString("type");
        Map<String,Object> param = new HashMap<>();
        param.put("type",type);
        List<Map<String ,Object>> results = goodsServiceImp.classify(param);
        JSONObject jsonObject = new JSONObject();
        JSONArray jsonArray = new JSONArray();
        for(Map<String,Object> result:results){
            JSONObject paramJSON = new JSONObject();
            paramJSON.put("title",result.get("title"));
            paramJSON.put("dateTime",result.get("dateTime"));
            paramJSON.put("price",result.get("price"));
            paramJSON.put("type",result.get("type"));
            jsonArray.add(paramJSON);
        }
        jsonObject.put("msg",jsonArray);
        return jsonObject.toString();
    }

    @RequestMapping(value = "/addData", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    @CrossOrigin
    @ResponseBody
    private String addData(@RequestBody String addJSON) throws Exception{
        JSONObject AddJson = JSONObject.parseObject(addJSON);
        String title = AddJson.getString("title");
        String dateTime = AddJson.getString("dateTime");
        String price = AddJson.getString("price");
        String type = AddJson.getString("type");
        Map<String ,Object> param = new HashMap<>();
        param.put("title",title);
        param.put("desc",dateTime);
        param.put("price",price);
        param.put("type",type);
        JSONObject jsonObject = new JSONObject();
        try{
            goodsServiceImp.addInfo(param);
            jsonObject.put("flag","1");
            jsonObject.put("msg","添加商品成功!");
        }catch (Exception e){
            jsonObject.put("flag","0");
            jsonObject.put("msg","添加商品失败!");
        }
        return jsonObject.toString();
    }

    @RequestMapping(value = "/UpdateInfo", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    @CrossOrigin
    @ResponseBody
    private String UpdateInfo(@RequestBody String UpdateJSON) throws Exception{
        JSONObject UpdateJson = JSONObject.parseObject(UpdateJSON);
        String title = UpdateJson.getString("title");
        String dateTime = UpdateJson.getString("dateTime");
        String price = UpdateJson.getString("price");
        String id = UpdateJson.getString("id");
        String type = UpdateJson.getString("type");
        Map<String, Object> param = new HashMap<>();
        param.put("title",title);
        param.put("dateTime",dateTime);
        param.put("price",price);
        param.put("type",type);
        param.put("id",id);
        int result= goodsServiceImp.UpdateInfo(param);
        JSONObject jsonObject = new JSONObject();
        if(result == 1){
            jsonObject.put("flag","1");
            jsonObject.put("msg","更新商品成功");
        }else{
            jsonObject.put("flag","0");
            jsonObject.put("msg","更新商品失败");
        }
        return jsonObject.toString();
    }

    @RequestMapping(value = "/DeleteInfo", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    @CrossOrigin
    @ResponseBody
    private String DeleteInfo(@RequestBody String DeleteJSON) throws Exception{
        JSONObject DeleteJson = JSONObject.parseObject(DeleteJSON);
        String id = DeleteJson.getString("id");

        Map<String ,Object> param = new HashMap<>();
        int i = Integer.parseInt(id);
        param.put("id",i);
        int result = goodsServiceImp.DeleteInfo(param);
        JSONObject jsonObject = new JSONObject();

        if (result != 0 ){
            jsonObject.put("flag","1");
            jsonObject.put("msg","删除商品成功");
        }else {
            jsonObject.put("flag","0");
            jsonObject.put("msg","删除商品失败");
        }
        return jsonObject.toString();
    }
}
