package com.example.demo01.dao.User;

import com.sun.corba.se.spi.ior.ObjectKey;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.session.RowBounds;

import java.util.List;
import java.util.Map;

@Mapper
public interface UserMapper {
    //用户登陆，返回用户名与用户加密后的密码
    Map<String, Object> UserLogin(@Param(value = "UserName") String UserName);
    //注册用户
    int AddUser(Map<String, Object> param);
    //更新用户信息
    int UpdateUserInfo(Map<String ,Object> param);
    //删除用户信息
    int DeleteUserInfo(Map<String, Object> param);
}
