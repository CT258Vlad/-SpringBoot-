package com.example.demo01.dao.Goods;

import com.example.demo01.model.Goods;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;
import java.util.Map;

@Mapper
public interface GoodsMapper {
    int addInfo(Map<String, Object> param);

    List<Goods> getInfo();

    List<Map<String,Object>> queryInfo(Map<String,Object> param);

    List<Map<String,Object>> classify(Map<String,Object> param);

    int UpdateInfo(Map<String ,Object> param);

    int DeleteInfo(Map<String, Object> param);
}
