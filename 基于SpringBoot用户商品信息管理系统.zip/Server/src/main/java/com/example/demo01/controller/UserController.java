package com.example.demo01.controller;

import com.example.demo01.dao.User.UserServiceImp;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import com.alibaba.fastjson.JSONObject;

import java.util.HashMap;
import java.util.Map;

@RestController
public class UserController {
    @Autowired
    UserServiceImp userServiceImp;

    @RequestMapping(value = "/UserLogin", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    @CrossOrigin
    private String UserLogin(@RequestBody String LoginJSON) throws Exception {
        JSONObject LoginJson = JSONObject.parseObject(LoginJSON);
        //获取登录名与登录密码
        String LoginNameInfo = LoginJson.getString("UserName");
        String LoginPasswordInfo = LoginJson.getString("Password");
        Map<String,Object> userInfo = userServiceImp.UserLogin(LoginNameInfo);
        JSONObject jsonObject = new JSONObject();
        System.out.println(LoginNameInfo);
        System.out.println(LoginPasswordInfo);
        if(userInfo == null){
            jsonObject.put("flag","0");
            jsonObject.put("msg","账号不存在!");
            return jsonObject.toString();
        }
        else{
            String UserName = (String) userInfo.get("UserName");
            String Password = (String)userInfo.get("Password");
            System.out.println(UserName);
            System.out.println(Password);
            if(LoginPasswordInfo.equals(Password)){
                jsonObject.put("flag",1);
                jsonObject.put("msg","登录成功!");
            }
            else {
                jsonObject.put("flag", "0");
                jsonObject.put("msg", "账号或者密码错误");
            }
        }
        return jsonObject.toString();
    }

    @RequestMapping(value = "/addUser", method = RequestMethod.POST)
    @CrossOrigin
    private String AddUser(@RequestBody String addJSON) throws Exception{
        JSONObject AddJson = JSONObject.parseObject(addJSON);
        String UserName = AddJson.getString("UserName");
        String Password = AddJson.getString("Password");
        System.out.println(UserName);
        System.out.println(Password);
        Map<String ,Object> param = new HashMap<>();
        param.put("UserName",UserName);
        param.put("Password",Password);

        JSONObject jsonObject = new JSONObject();
        try{
            userServiceImp.AddUser(param);
            jsonObject.put("flag","1");
            jsonObject.put("msg","注册成功");
        }catch (Exception e){
            userServiceImp.AddUser(param);
            jsonObject.put("flag","1");
            jsonObject.put("msg","注册成功");
        }
        return jsonObject.toString();
    }

    @RequestMapping(value = "/UpdateUserInfo", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    @CrossOrigin
    private String UpdateUserInfo(@RequestBody String UpdateJSON) throws Exception{
        JSONObject UpdateJson = JSONObject.parseObject(UpdateJSON);
        String UserName = UpdateJson.getString("UserName");
        String Password = UpdateJson.getString("Password");
        String id = UpdateJson.getString("id");
        Map<String, Object> param = new HashMap<>();
        param.put("id",id);
        param.put("UserName",UserName);
        param.put("Password",Password);
        int result= userServiceImp.UpdateUserInfo(param);
        JSONObject jsonObject = new JSONObject();
        if(result == 1){
            jsonObject.put("flag","1");
            jsonObject.put("msg","更新成功");
        }else{
            jsonObject.put("flag","0");
            jsonObject.put("msg","更新失败");
        }
        return jsonObject.toString();
    }

    @RequestMapping(value = "/DeleteUserInfo", method = RequestMethod.POST, produces = MediaType.APPLICATION_JSON_VALUE)
    @CrossOrigin
    private String DeleteUserInfo(@RequestBody String DeleteJSON) throws Exception{
        JSONObject DeleteJson = JSONObject.parseObject(DeleteJSON);
        String id = DeleteJson.getString("id");

        Map<String ,Object> param = new HashMap<>();
        int i = Integer.parseInt(id);
        param.put("id",i);
        int result = userServiceImp.DeleteUserInfo(param);
        JSONObject jsonObject = new JSONObject();

        if (result !=0 ){
            jsonObject.put("flag","1");
            jsonObject.put("msg","删除成功");
        }else {
            jsonObject.put("flag","0");
            jsonObject.put("msg","删除失败");
        }
        return jsonObject.toString();
    }
}