package com.example.demo01.dao.Goods;

import com.example.demo01.model.Goods;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.annotation.Resource;
import java.util.List;
import java.util.Map;

@Service
public class GoodsServiceImp {
    @Resource
    @Autowired
    GoodsMapper goodsMapper;

    public List<Goods> getInfo()
    {
        return goodsMapper.getInfo();
    }

    public int addInfo(Map<String, Object> param){
        return goodsMapper.addInfo(param);
    }

    public int UpdateInfo(Map<String, Object>param){
        return goodsMapper.UpdateInfo(param);
    }

    public List<Map<String,Object>> queryInfo(Map<String,Object> param){
        return  goodsMapper.queryInfo(param);
    }

    public List<Map<String,Object>> classify(Map<String,Object> param){
        return  goodsMapper.classify(param);
    }

    public int DeleteInfo(Map<String, Object> param){
        return goodsMapper.DeleteInfo(param);
    }
}