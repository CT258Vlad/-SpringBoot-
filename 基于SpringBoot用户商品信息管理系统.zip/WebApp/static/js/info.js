$(document).ready(function(){
    var title;var desc;var price;
    $("#back").click(function(){
        window.location.href="../templates/index.html"
    })
    $.ajax
    ({
        async:true,
        type: "POST",
        url: "http://localhost:8080/getData",
        dataType: "json",
        data: JSON.stringify(),
        contentType: "application/json",
        success: function (res) {
            console.log(res)
            for(var i=0; i<res.length; i++){
                tr = '<td id="id">' + i +'</td>'
                    +'<td id="title">'+res[i].title+'</td>'
                    +'<td id="desc">' +res[i].dateTime+'</td>'
                    +'<td id="price">'+res[i].price+'</td>'
                    +'<td id="type">'+res[i].type+'</td>';
                $("#table").append('<tr id="current" style="height: 30px; align-content: center">' + tr + '</tr>');
            }
        }
    });
})