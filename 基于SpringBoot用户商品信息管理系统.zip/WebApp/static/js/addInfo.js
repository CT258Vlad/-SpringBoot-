$(document).ready(function(){
    var title;
    var dateTime;
    var price;
    var type;
    $("#back").click(function(){
        window.location.href="../templates/index.html"
    })
    $("#add").click(function () {
        $("#add").mouseenter(function(){
            $("#register_btn").css("background-color","WhiteSmoke");
        });
        $("#add").mouseleave(function(){
            $("#add").css("background-color","lightgray");
        });
        var d=new Date();
        var year=d.getFullYear();
        var month=change(d.getMonth()+1);
        var day=change(d.getDate());
        var hour=change(d.getHours());
        var minute=change(d.getMinutes());
        var second=change(d.getSeconds());
        function change(t){
            if(t<10){
                return "0"+t;
            }else{
                return t;
            }
        }
        dateTime=year+'-'+month+'-'+day+' '+hour+':'+minute+':'+second;
        title = $("#title").val();
        price = $("#price").val();
        type  = $("#type").val();
        $.ajax
        ({
            async:true,
            type: "POST",
            url: "http://localhost:8080/addData",
            dataType: "json",
            data: JSON.stringify({
                "title": title,
                "dateTime": dateTime,
                "price": price,
                "type":type
            }),
            contentType: "application/json",
            success: function (data) {
                console.log(data);
                var flag = data.flag;
                if(flag == 1){
                    alert(data.msg);
                }else{
                    alert("添加失败");
                }
            }
        })
    })
    $("#btn_bc").click(function () {
        $("#btn_bc").mouseenter(function () {
            $("#btn_bc").css("background-color", "WhiteSmoke");
        });
        $("#btn_bc").mouseleave(function () {
            $("#btn_bc").css("background-color", "lightgray");
        });
        window.location.href="index.html";
    });
})