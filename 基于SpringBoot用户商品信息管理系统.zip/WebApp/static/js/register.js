$(document).ready(function(){
    var UserName;
    var Password;
    $("#register_btn").click(function () {
        $("#register_btn").mouseenter(function(){
            $("#register_btn").css("background-color","WhiteSmoke");
        });
        $("#register_btn").mouseleave(function(){
            $("#register_btn").css("background-color","lightgray");
        });
        UserName = $("#username").val();
        Password = $("#password").val();
        var confirm_pwd = $("#confirm_password").val();
        if(Password == confirm_pwd){
            $.ajax
            ({
                async:true,
                type: "POST",
                url: "http://localhost:8080/addUser",
                dataType: "json",
                data: JSON.stringify({
                    "UserName": UserName,
                    "Password": Password
                }),
                contentType: "application/json",
                success: function (data) {
                    console.log(data);
                    var flag = data.flag;
                    if(flag == 1){
                        alert(data.msg);
                        window.location.href = "login.html";
                    }else{
                        alert("注册失败");
                    }
                }
            })
        }
    })
    $("#back").click(function () {
        $("#back").mouseenter(function () {
            $("#back").css("background-color", "WhiteSmoke");
        });
        $("#back").mouseleave(function () {
            $("#back").css("background-color", "lightgray");
        });
        window.location.href="index.html";
    });
})