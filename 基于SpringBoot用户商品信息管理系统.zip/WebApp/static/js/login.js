$(document).ready(function(){
    var UserName;
    var Password;
    $("#entry_btn").click(function () {
        $("#entry_btn").mouseenter(function(){
            $("#entry_btn").css("background-color","WhiteSmoke");
        });
        $("#entry_btn").mouseleave(function(){
            $("#entry_btn").css("background-color","lightgray");
        });
        UserName = $("#username").val();
        Password = $("#password").val();
        $.ajax
        ({
            async:true,
            type: "POST",
            url: "http://localhost:8080/UserLogin",
            dataType: "json",
            data: JSON.stringify({
                "UserName": UserName,
                "Password": Password,
            }),
            contentType: "application/json",
            success: function (data) {
                console.log(data);
                var flag = data.flag;
                if(flag == 1){
                    alert(data.msg);
                    localStorage.setItem('UserName',UserName);
                    window.location.href="index.html";
                }else{
                    alert("登录失败");
                }
            }
        })
    })
})