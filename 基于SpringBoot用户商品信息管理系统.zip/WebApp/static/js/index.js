
var UserName = localStorage.getItem("UserName");

var audit = new Vue({
    el:'#audit',
    data: {
        Name: UserName,
    }
})
$(document).ready(function(){
    $("#info").click(function(){
        window.location.href="ListInfo.html";
    })
    $("#class").click(function(){
        window.location.href="classify.html";
    })
    $("#addInfo").click(function(){
        window.location.href="addInfo.html";
    })
    $("#add").click(function(){
        window.location.href="register.html";
    })
    $("#logout").click(function(){
        window.location.href="login.html"
    })
    $("#search").click(function(){
        var title = $("#input").val();
        localStorage.setItem('title',title);
        window.location.href="queryInfo.html"
    })
})