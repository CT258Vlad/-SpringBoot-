$("#back").click(function(){
    window.location.href="index.html"
})

$(document).ready(function(){
    $("#back").click(function(){
        window.location.href="index.html"
    })
    var type;
    $("#snacks").click(function(){
        type = "零食";
        localStorage.setItem('type',type);
        window.location.href="classifyInfo.html";
    })
    $("#drinks").click(function(){
        type = "饮料";
        localStorage.setItem('type',type);
        window.location.href="classifyInfo.html";
    })
    $("#fresh").click(function(){
        type = "生鲜";
        localStorage.setItem('type',type);
        window.location.href="classifyInfo.html";
    })
    $("#daily").click(function(){
        type = "生活用品";
        localStorage.setItem('type',type);
        window.location.href="classifyInfo.html";
    })
})